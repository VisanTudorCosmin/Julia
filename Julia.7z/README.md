# Julia

Pentru a rula aplicatia avem nevoie ca Haskell si stack sa fie instalate pe calculator. Putem face acest lucru urmand pasii de [aici](https://docs.haskellstack.org/en/stable/).

Programul afiseaza imaginea generata de functia f(z) = z^2 + c, unde c poate sa fie variant in functie locul unde se afla cursorul pe fereastra aplicatie. 