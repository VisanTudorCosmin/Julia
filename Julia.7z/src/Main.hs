module Main (main) where

import Graphics.Gloss
import Graphics.Gloss.Interface.IO.Interact
import Data.Word
import Data.ByteString (ByteString, pack)
import qualified Data.ByteString as B
import Control.Monad
import GHC.Float

data Stare = Stare Picture (Double,Double)

afiseazaCoordonate :: Double -> Double -> Picture
afiseazaCoordonate x y = 
    translate (-250) (-250) $ 
    scale 0.1 0.1 $ 
    color black $ 
    text $ show x ++ " " ++ show y 

defaultImage = (createJuliaImage ((-0.0417),0.7116) 400)

afiseazaStare :: Stare -> Picture
afiseazaStare (Stare picture (x,y)) = pictures [ picture , afiseazaCoordonate x y]

modificaStare :: Event -> Stare -> Stare
modificaStare (EventMotion (x,y)) (Stare imagine _) = 
    let x' = 2 * (float2Double x) / 512 
        y' = 2 * (float2Double y) / 512 
    in Stare imagine (x',y')
modificaStare _ stare = stare

calculeaazaImagineNoua :: Float -> Stare -> Stare
calculeaazaImagineNoua _ (Stare _ (x, y)) = Stare (createJuliaImage (x,y) 300) (x, y)

main :: IO ()
main = play (InWindow "Fractal Julia" (512, 512) (10, 10)) white 20 (Stare defaultImage (0,0)) afiseazaStare modificaStare calculeaazaImagineNoua

createGrayScalePixel :: Int -> ByteString
createGrayScalePixel scale =
    let scaleWord = 255 - fromIntegral scale
    in pack [ scaleWord, scaleWord, scaleWord, 255 ]

createJuliaImage :: (Double, Double) -> Double -> Picture
createJuliaImage c size =
    let dataStream =  B.concat [ createGrayScalePixel $! calculeazaJulia c ((x/size),(y/size)) 0 | x <- [-size..size] , y <- [-size..size] ]
        len = 2 * (round size) + 1
    in bitmapOfByteString len len (BitmapFormat TopToBottom PxRGBA) dataStream False

nmax :: Int 
nmax = 64

calculeazaJulia :: (Double,Double) -> (Double, Double) -> Int -> Int
calculeazaJulia (cx,cy) (x,y) n | n > nmax = 190
calculeazaJulia (cx,cy) (x,y) n | x*x + y*y > 4 = if n + 40 > 255 then 255 else n + 40
calculeazaJulia (cx,cy) (x,y) n  = calculeazaJulia (cx,cy) (x*x - y*y + cx, 2*x*y + cy) (n+1) 


